export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
//este es una herramienta que permite transformar el css es un interprete